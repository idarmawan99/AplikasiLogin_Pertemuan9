Login Form with Shared Preferences
